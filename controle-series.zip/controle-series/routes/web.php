<?php


route::get('/series', 'SeriesController@index');
route::get('/series/criar', 'SeriesController@create');
route::post('/series/criar', 'SeriesController@store');
