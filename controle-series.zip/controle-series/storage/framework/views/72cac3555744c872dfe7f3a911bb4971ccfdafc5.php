<?php $__env->startSection('cabecalho'); ?>
    Adicionar Série
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
        <form method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nome" class="label">Nome: </label>
                <input type="text" class="form-control" name="nome" id="nome">
            </div>

            <button class="btn btn-primary"> Adicionar </button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cpb/Desktop/Cadastro/controle-series/resources/views/series/create.blade.php ENDPATH**/ ?>